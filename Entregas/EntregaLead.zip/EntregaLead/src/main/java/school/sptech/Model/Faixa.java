package school.sptech.Model;

public enum Faixa {
    BAIXO,
    MEDIO,
    ALTO,
    VIP
}
