package sptech.projeto03;

public class Pet {
    private Integer id;
    private String nomePet;
    private String nomeDono;
    private String especie;
    private String raca;

    public Integer getId() {
        return id;
    }

    public String getNomePet() {
        return nomePet;
    }

    public String getNomeDono() {
        return nomeDono;
    }

    public String getEspecie() {
        return especie;
    }

    public String getRaca() {
        return raca;
    }
}
