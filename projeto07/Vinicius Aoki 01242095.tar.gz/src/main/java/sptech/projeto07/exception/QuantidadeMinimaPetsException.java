package sptech.projeto07.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/*
Exemplo de exceção personalizada com mensagem estática (fixa).
IMPORTANTE: A classe DEVE estender RuntimeException
 */
@ResponseStatus(
    code = HttpStatus.UNPROCESSABLE_ENTITY,
    reason = "A quantidade mínima de pets é 1"
)
public class QuantidadeMinimaPetsException
        extends RuntimeException {
}
